import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Download, 
  FileText, 
  Trash2, 
  Search, 
  Calendar,
  DollarSign,
  Users,
  BarChart3,
  FileSpreadsheet
} from 'lucide-react';
import { Invoice, getInvoices, deleteInvoice, formatCurrency } from '@/lib/invoice';
import { generateInvoicePDF, generateInvoiceSummaryPDF, generateAllInvoicesPDF } from '@/lib/pdfGenerator';
import { generateInvoiceSummaryExcel, generateDetailedInvoiceExcel } from '@/lib/excelGenerator';

interface InvoiceHistoryProps {
  onEditInvoice: (invoice: Invoice) => void;
}

export default function InvoiceHistory({ onEditInvoice }: InvoiceHistoryProps) {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [filteredInvoices, setFilteredInvoices] = useState<Invoice[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [dateFilter, setDateFilter] = useState('');

  useEffect(() => {
    loadInvoices();
  }, []);

  useEffect(() => {
    filterInvoices();
  }, [invoices, searchTerm, dateFilter]);

  const loadInvoices = () => {
    const savedInvoices = getInvoices();
    setInvoices(savedInvoices);
  };

  const filterInvoices = () => {
    let filtered = invoices;

    if (searchTerm) {
      filtered = filtered.filter(invoice =>
        invoice.clientName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        invoice.invoiceNumber?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        invoice.businessName?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (dateFilter) {
      filtered = filtered.filter(invoice =>
        invoice.date?.startsWith(dateFilter)
      );
    }

    setFilteredInvoices(filtered);
  };

  const handleDeleteInvoice = (id: string) => {
    if (window.confirm('Are you sure you want to delete this invoice?')) {
      deleteInvoice(id);
      loadInvoices();
    }
  };

  const handleDownloadPDF = async (invoice: Invoice) => {
    await generateInvoicePDF(invoice);
  };

  const handleDownloadSummaryPDF = async () => {
    await generateInvoiceSummaryPDF(filteredInvoices);
  };

  const handleDownloadAllPDF = async () => {
    await generateAllInvoicesPDF(filteredInvoices);
  };

  const handleDownloadSummaryExcel = () => {
    generateInvoiceSummaryExcel(filteredInvoices);
  };

  const handleDownloadDetailedExcel = () => {
    generateDetailedInvoiceExcel(filteredInvoices);
  };

  // Calculate statistics
  const totalAmount = filteredInvoices.reduce((sum, inv) => sum + (inv.total || 0), 0);
  const uniqueClients = new Set(filteredInvoices.map(inv => inv.clientName)).size;
  const avgInvoiceAmount = filteredInvoices.length > 0 ? totalAmount / filteredInvoices.length : 0;

  return (
    <div className="space-y-6">
      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <FileText className="h-8 w-8 text-blue-600" />
              <div>
                <p className="text-2xl font-bold">{filteredInvoices.length}</p>
                <p className="text-sm text-gray-600">Total Invoices</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <DollarSign className="h-8 w-8 text-green-600" />
              <div>
                <p className="text-2xl font-bold">${totalAmount.toFixed(2)}</p>
                <p className="text-sm text-gray-600">Total Amount</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Users className="h-8 w-8 text-purple-600" />
              <div>
                <p className="text-2xl font-bold">{uniqueClients}</p>
                <p className="text-sm text-gray-600">Unique Clients</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <BarChart3 className="h-8 w-8 text-orange-600" />
              <div>
                <p className="text-2xl font-bold">${avgInvoiceAmount.toFixed(2)}</p>
                <p className="text-sm text-gray-600">Avg. Invoice</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Export Options */}
      <Card className="border-green-200 bg-green-50/50">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Download className="h-5 w-5 text-green-600" />
            <span>Export & Download Options</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <Button 
              onClick={handleDownloadSummaryPDF}
              className="flex items-center space-x-2"
              variant="outline"
            >
              <FileText className="h-4 w-4" />
              <span>Summary PDF</span>
            </Button>

            <Button 
              onClick={handleDownloadAllPDF}
              className="flex items-center space-x-2"
              variant="outline"
            >
              <FileText className="h-4 w-4" />
              <span>All Invoices PDF</span>
            </Button>

            <Button 
              onClick={handleDownloadSummaryExcel}
              className="flex items-center space-x-2"
              variant="outline"
            >
              <FileSpreadsheet className="h-4 w-4" />
              <span>Summary Excel</span>
            </Button>

            <Button 
              onClick={handleDownloadDetailedExcel}
              className="flex items-center space-x-2"
              variant="outline"
            >
              <FileSpreadsheet className="h-4 w-4" />
              <span>Detailed Excel</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle>Filter Invoices</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="search">Search</Label>
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  id="search"
                  placeholder="Search by client name, invoice number..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="dateFilter">Filter by Month</Label>
              <div className="relative">
                <Calendar className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  id="dateFilter"
                  type="month"
                  value={dateFilter}
                  onChange={(e) => setDateFilter(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Invoice List */}
      <Card>
        <CardHeader>
          <CardTitle>Invoice History ({filteredInvoices.length} invoices)</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredInvoices.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              <FileText className="h-16 w-16 mx-auto mb-4 text-gray-300" />
              <h3 className="text-lg font-semibold mb-2">No invoices found</h3>
              <p>Create your first invoice or adjust your filters</p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredInvoices.map((invoice) => (
                <div key={invoice.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <h3 className="font-semibold text-lg">#{invoice.invoiceNumber}</h3>
                        <Badge variant="secondary" className="text-xs">
                          {invoice.language?.toUpperCase()}
                        </Badge>
                        <Badge variant="outline" className="text-xs">
                          {invoice.currency}
                        </Badge>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-600">
                        <div>
                          <p className="font-medium text-gray-900">{invoice.clientName}</p>
                          <p>{invoice.clientEmail}</p>
                        </div>
                        <div>
                          <p>Date: {invoice.date ? new Date(invoice.date).toLocaleDateString() : 'N/A'}</p>
                          <p>Due: {invoice.dueDate ? new Date(invoice.dueDate).toLocaleDateString() : 'N/A'}</p>
                        </div>
                        <div>
                          <p className="font-semibold text-lg text-green-600">
                            {formatCurrency(invoice.total || 0, invoice.currency || 'USD')}
                          </p>
                          <p>{invoice.items?.length || 0} items</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex space-x-2 ml-4">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleDownloadPDF(invoice)}
                        className="flex items-center space-x-1"
                      >
                        <Download className="h-4 w-4" />
                        <span>PDF</span>
                      </Button>
                      
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => onEditInvoice(invoice)}
                        className="flex items-center space-x-1"
                      >
                        <FileText className="h-4 w-4" />
                        <span>Edit</span>
                      </Button>
                      
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleDeleteInvoice(invoice.id)}
                        className="flex items-center space-x-1 text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="h-4 w-4" />
                        <span>Delete</span>
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}