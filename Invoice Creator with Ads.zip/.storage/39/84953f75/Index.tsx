import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Globe, FileText, Plus, Languages, DollarSign, History, Download } from 'lucide-react';
import { SUPPORTED_LANGUAGES, SUPPORTED_CURRENCIES, createEmptyInvoice, Invoice } from '@/lib/invoice';
import InvoiceForm from '@/components/InvoiceForm';
import InvoiceTemplate from '@/components/InvoiceTemplate';
import InvoiceHistory from '@/components/InvoiceHistory';
import { generateInvoicePDF } from '@/lib/pdfGenerator';

export default function Index() {
  const [currentInvoice, setCurrentInvoice] = useState(createEmptyInvoice());
  const [currentView, setCurrentView] = useState<'home' | 'create' | 'history'>('home');

  const handleCreateInvoice = (language?: string, currency?: string) => {
    const newInvoice = createEmptyInvoice();
    if (language) newInvoice.language = language;
    if (currency) newInvoice.currency = currency;
    setCurrentInvoice(newInvoice);
    setCurrentView('create');
  };

  const handleEditInvoice = (invoice: Invoice) => {
    setCurrentInvoice(invoice);
    setCurrentView('create');
  };

  const handleDownloadCurrentPDF = async () => {
    await generateInvoicePDF(currentInvoice);
  };

  if (currentView === 'create') {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="container mx-auto px-4 py-8">
          <div className="mb-6 flex justify-between items-center">
            <div className="space-x-2">
              <Button 
                variant="outline" 
                onClick={() => setCurrentView('home')}
              >
                ← Back to Home
              </Button>
              <Button 
                variant="outline" 
                onClick={() => setCurrentView('history')}
              >
                <History className="h-4 w-4 mr-2" />
                View History
              </Button>
            </div>
            
            <Button 
              onClick={handleDownloadCurrentPDF}
              className="flex items-center space-x-2"
            >
              <Download className="h-4 w-4" />
              <span>Download PDF</span>
            </Button>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="space-y-6">
              <h1 className="text-3xl font-bold text-gray-900">Create Invoice</h1>
              <InvoiceForm invoice={currentInvoice} onChange={setCurrentInvoice} />
            </div>
            
            <div className="lg:sticky lg:top-8">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Preview</h2>
              <InvoiceTemplate invoice={currentInvoice} />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (currentView === 'history') {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="container mx-auto px-4 py-8">
          <div className="mb-6 flex justify-between items-center">
            <div className="space-x-2">
              <Button 
                variant="outline" 
                onClick={() => setCurrentView('home')}
              >
                ← Back to Home
              </Button>
              <Button 
                onClick={() => handleCreateInvoice()}
                className="flex items-center space-x-2"
              >
                <Plus className="h-4 w-4" />
                <span>Create New Invoice</span>
              </Button>
            </div>
          </div>
          
          <div className="space-y-6">
            <h1 className="text-3xl font-bold text-gray-900">Invoice History & Reports</h1>
            <InvoiceHistory onEditInvoice={handleEditInvoice} />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50">
      <div className="container mx-auto px-4 py-12">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <div className="mb-8">
            <FileText className="h-16 w-16 text-blue-600 mx-auto mb-4" />
            <h1 className="text-5xl font-bold bg-gradient-to-r from-blue-600 to-green-600 bg-clip-text text-transparent mb-4">
              Professional Invoice Creator
            </h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Create beautiful, multilingual invoices with custom branding, multiple currencies, and professional templates
            </p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button 
              onClick={() => handleCreateInvoice()} 
              size="lg"
              className="bg-gradient-to-r from-blue-600 to-green-600 hover:from-blue-700 hover:to-green-700 text-white px-8 py-3 text-lg"
            >
              <Plus className="h-5 w-5 mr-2" />
              Create Invoice Now
            </Button>
            
            <Button 
              onClick={() => setCurrentView('history')} 
              size="lg"
              variant="outline"
              className="px-8 py-3 text-lg"
            >
              <History className="h-5 w-5 mr-2" />
              View History & Reports
            </Button>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-16">
          <Card className="border-blue-200 hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-blue-700">
                <Languages className="h-6 w-6" />
                <span>12 Languages</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">
                Support for multiple languages with complete translations and RTL support for Arabic and Urdu.
              </p>
              <div className="text-sm text-gray-500">
                English, Spanish, French, German, Italian, Portuguese, Chinese, Japanese, Korean, Arabic, Urdu, Bengali
              </div>
            </CardContent>
          </Card>

          <Card className="border-green-200 hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-green-700">
                <DollarSign className="h-6 w-6" />
                <span>16 Currencies</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">
                Support for major world currencies with proper formatting and symbols.
              </p>
              <div className="text-sm text-gray-500">
                USD, EUR, GBP, JPY, CAD, AUD, CHF, CNY, INR, BRL, MXN, KRW, SAR, AED, PKR, BDT
              </div>
            </CardContent>
          </Card>

          <Card className="border-purple-200 hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-purple-700">
                <FileText className="h-6 w-6" />
                <span>Custom Labels</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">
                Fully customizable headers and labels. Create invoices, quotes, estimates, or receipts.
              </p>
              <div className="text-sm text-gray-500">
                Edit all field names, headers, and messages to match your business needs
              </div>
            </CardContent>
          </Card>

          <Card className="border-orange-200 hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-orange-700">
                <Download className="h-6 w-6" />
                <span>Export & Reports</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">
                Download individual PDFs, bulk exports, and comprehensive Excel reports with analytics.
              </p>
              <div className="text-sm text-gray-500">
                PDF downloads, Excel summaries, invoice history, and detailed analytics
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Start Section */}
        <div className="bg-white rounded-2xl shadow-lg p-8 mb-16">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-8">Quick Start</h2>
          <p className="text-center text-gray-600 mb-8">
            Choose your preferred language and currency to get started with a pre-configured invoice
          </p>
          
          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {/* Popular Language/Currency combinations */}
              <Card className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => handleCreateInvoice('en', 'USD')}>
                <CardContent className="p-6 text-center">
                  <div className="text-2xl mb-2">🇺🇸</div>
                  <h3 className="font-semibold text-gray-900">English (US)</h3>
                  <p className="text-sm text-gray-600">USD - US Dollar</p>
                </CardContent>
              </Card>

              <Card className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => handleCreateInvoice('es', 'EUR')}>
                <CardContent className="p-6 text-center">
                  <div className="text-2xl mb-2">🇪🇸</div>
                  <h3 className="font-semibold text-gray-900">Español</h3>
                  <p className="text-sm text-gray-600">EUR - Euro</p>
                </CardContent>
              </Card>

              <Card className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => handleCreateInvoice('fr', 'EUR')}>
                <CardContent className="p-6 text-center">
                  <div className="text-2xl mb-2">🇫🇷</div>
                  <h3 className="font-semibold text-gray-900">Français</h3>
                  <p className="text-sm text-gray-600">EUR - Euro</p>
                </CardContent>
              </Card>

              <Card className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => handleCreateInvoice('de', 'EUR')}>
                <CardContent className="p-6 text-center">
                  <div className="text-2xl mb-2">🇩🇪</div>
                  <h3 className="font-semibold text-gray-900">Deutsch</h3>
                  <p className="text-sm text-gray-600">EUR - Euro</p>
                </CardContent>
              </Card>

              <Card className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => handleCreateInvoice('zh', 'CNY')}>
                <CardContent className="p-6 text-center">
                  <div className="text-2xl mb-2">🇨🇳</div>
                  <h3 className="font-semibold text-gray-900">中文</h3>
                  <p className="text-sm text-gray-600">CNY - Chinese Yuan</p>
                </CardContent>
              </Card>

              <Card className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => handleCreateInvoice('ja', 'JPY')}>
                <CardContent className="p-6 text-center">
                  <div className="text-2xl mb-2">🇯🇵</div>
                  <h3 className="font-semibold text-gray-900">日本語</h3>
                  <p className="text-sm text-gray-600">JPY - Japanese Yen</p>
                </CardContent>
              </Card>

              <Card className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => handleCreateInvoice('ar', 'SAR')}>
                <CardContent className="p-6 text-center">
                  <div className="text-2xl mb-2">🇸🇦</div>
                  <h3 className="font-semibold text-gray-900">العربية</h3>
                  <p className="text-sm text-gray-600">SAR - Saudi Riyal</p>
                </CardContent>
              </Card>

              <Card className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => handleCreateInvoice('ur', 'PKR')}>
                <CardContent className="p-6 text-center">
                  <div className="text-2xl mb-2">🇵🇰</div>
                  <h3 className="font-semibold text-gray-900">اردو</h3>
                  <p className="text-sm text-gray-600">PKR - Pakistani Rupee</p>
                </CardContent>
              </Card>

              <Card className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => handleCreateInvoice('bn', 'BDT')}>
                <CardContent className="p-6 text-center">
                  <div className="text-2xl mb-2">🇧🇩</div>
                  <h3 className="font-semibold text-gray-900">বাংলা</h3>
                  <p className="text-sm text-gray-600">BDT - Bangladeshi Taka</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>

        {/* All Languages Section */}
        <div className="bg-gradient-to-r from-blue-600 to-green-600 rounded-2xl shadow-lg p-8 text-white">
          <h2 className="text-3xl font-bold text-center mb-8">All Supported Languages</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 max-w-4xl mx-auto">
            {Object.entries(SUPPORTED_LANGUAGES).map(([code, name]) => (
              <div 
                key={code}
                className="bg-white/10 backdrop-blur-sm rounded-lg p-4 text-center hover:bg-white/20 transition-colors cursor-pointer"
                onClick={() => handleCreateInvoice(code)}
              >
                <div className="font-semibold text-lg">{name}</div>
                <div className="text-sm opacity-80">{code.toUpperCase()}</div>
              </div>
            ))}
          </div>
          
          <div className="text-center mt-8">
            <p className="text-lg opacity-90 mb-4">
              Click any language above to start creating an invoice in that language
            </p>
            <Button 
              variant="secondary" 
              size="lg"
              onClick={() => handleCreateInvoice()}
              className="bg-white text-blue-600 hover:bg-gray-100"
            >
              <Globe className="h-5 w-5 mr-2" />
              Create Custom Invoice
            </Button>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-16 text-gray-500">
          <p>Professional invoice creator supporting 12 languages and 16 currencies</p>
          <p className="text-sm mt-2">Perfect for international businesses and freelancers</p>
        </div>
      </div>
    </div>
  );
}