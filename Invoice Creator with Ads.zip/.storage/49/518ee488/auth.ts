export interface User {
  id: string;
  email: string;
  name: string;
  createdAt: string;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
}

const AUTH_STORAGE_KEY = 'invoice_auth';
const USERS_STORAGE_KEY = 'invoice_users';

export const getStoredAuth = (): AuthState => {
  try {
    const stored = localStorage.getItem(AUTH_STORAGE_KEY);
    if (stored) {
      const auth = JSON.parse(stored);
      return {
        user: auth.user,
        isAuthenticated: !!auth.user
      };
    }
  } catch (error) {
    console.error('Error loading auth state:', error);
  }
  
  return {
    user: null,
    isAuthenticated: false
  };
};

export const setStoredAuth = (auth: AuthState): void => {
  try {
    localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(auth));
  } catch (error) {
    console.error('Error saving auth state:', error);
  }
};

export const getStoredUsers = (): User[] => {
  try {
    const stored = localStorage.getItem(USERS_STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (error) {
    console.error('Error loading users:', error);
    return [];
  }
};

export const setStoredUsers = (users: User[]): void => {
  try {
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
  } catch (error) {
    console.error('Error saving users:', error);
  }
};

export const signUp = (email: string, password: string, name: string): { success: boolean; user?: User; error?: string } => {
  const users = getStoredUsers();
  
  // Check if user already exists
  if (users.find(u => u.email === email)) {
    return { success: false, error: 'User already exists with this email' };
  }
  
  // Create new user
  const newUser: User = {
    id: Date.now().toString(),
    email,
    name,
    createdAt: new Date().toISOString()
  };
  
  // Store user (in real app, password would be hashed)
  const updatedUsers = [...users, newUser];
  setStoredUsers(updatedUsers);
  
  // Store password separately (in real app, this would be handled by backend)
  localStorage.setItem(`password_${newUser.id}`, password);
  
  return { success: true, user: newUser };
};

export const signIn = (email: string, password: string): { success: boolean; user?: User; error?: string } => {
  const users = getStoredUsers();
  const user = users.find(u => u.email === email);
  
  if (!user) {
    return { success: false, error: 'User not found' };
  }
  
  // Check password (in real app, this would be handled by backend)
  const storedPassword = localStorage.getItem(`password_${user.id}`);
  if (storedPassword !== password) {
    return { success: false, error: 'Invalid password' };
  }
  
  return { success: true, user };
};

export const signOut = (): void => {
  setStoredAuth({
    user: null,
    isAuthenticated: false
  });
};

export const getCurrentUser = (): User | null => {
  const auth = getStoredAuth();
  return auth.user;
};