import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { Invoice, getLabels, formatCurrency } from './invoice';

// Add font support for different languages
const addFontSupport = (pdf: jsPDF, language?: string) => {
  // For RTL languages and special characters, we'll use a more robust approach
  if (language === 'ar' || language === 'ur') {
    // For Arabic and Urdu, we need RTL support
    pdf.setFont('helvetica');
    pdf.setLanguage('ar');
  } else if (language === 'zh' || language === 'ja' || language === 'ko') {
    // For CJK languages
    pdf.setFont('helvetica');
  } else if (language === 'bn') {
    // For Bengali
    pdf.setFont('helvetica');
  } else {
    // Default for Latin-based languages
    pdf.setFont('helvetica');
  }
};

// Helper function to handle text direction and encoding
const addText = (pdf: jsPDF, text: string, x: number, y: number, language?: string, options?: { align?: string; maxWidth?: number }) => {
  try {
    // Handle RTL languages
    if (language === 'ar' || language === 'ur') {
      // For RTL languages, we need to reverse the text direction
      if (options?.align === 'right') {
        pdf.text(text, x, y, { align: 'right' });
      } else {
        pdf.text(text, x, y);
      }
    } else {
      // For LTR languages
      if (options?.maxWidth) {
        const lines = pdf.splitTextToSize(text, options.maxWidth);
        pdf.text(lines, x, y);
        return lines.length * 6; // Return height used
      } else {
        pdf.text(text, x, y, options as any);
      }
    }
    return 6; // Default line height
  } catch (error) {
    console.warn('Text rendering error:', error);
    // Fallback to basic text rendering
    pdf.text(text || '', x, y);
    return 6;
  }
};

export const generateInvoicePDF = async (invoice: Partial<Invoice>): Promise<void> => {
  const labels = getLabels(invoice);
  const currency = invoice.currency || 'USD';
  const language = invoice.language || 'en';
  
  // Create new PDF document
  const pdf = new jsPDF('p', 'mm', 'a4');
  const pageWidth = pdf.internal.pageSize.getWidth();
  const pageHeight = pdf.internal.pageSize.getHeight();
  
  // Set up fonts for the specific language
  addFontSupport(pdf, language);
  
  // Determine if this is an RTL language
  const isRTL = language === 'ar' || language === 'ur';
  const leftMargin = isRTL ? pageWidth - 170 : 20;
  const rightMargin = isRTL ? 20 : pageWidth - 60;
  
  // Header
  pdf.setFontSize(24);
  pdf.setTextColor(51, 51, 51);
  addText(pdf, labels.invoice, leftMargin, 30, language);
  
  // Invoice number
  pdf.setFontSize(12);
  pdf.setTextColor(102, 102, 102);
  addText(pdf, `#${invoice.invoiceNumber || ''}`, leftMargin, 40, language);
  
  // Date information
  const dateText = `${labels.date}: ${invoice.date ? new Date(invoice.date).toLocaleDateString() : ''}`;
  const dueText = `${labels.due}: ${invoice.dueDate ? new Date(invoice.dueDate).toLocaleDateString() : ''}`;
  
  if (isRTL) {
    addText(pdf, dateText, 20, 30, language);
    addText(pdf, dueText, 20, 40, language);
  } else {
    addText(pdf, dateText, rightMargin, 30, language);
    addText(pdf, dueText, rightMargin, 40, language);
  }
  
  // Business information
  let yPos = 60;
  pdf.setFontSize(14);
  pdf.setTextColor(51, 51, 51);
  addText(pdf, labels.from, leftMargin, yPos, language);
  
  yPos += 10;
  pdf.setFontSize(12);
  if (invoice.businessName) {
    addText(pdf, invoice.businessName, leftMargin, yPos, language);
    yPos += 6;
  }
  if (invoice.businessAddress) {
    const addressLines = invoice.businessAddress.split('\n');
    addressLines.forEach(line => {
      addText(pdf, line, leftMargin, yPos, language);
      yPos += 6;
    });
  }
  if (invoice.businessEmail) {
    addText(pdf, invoice.businessEmail, leftMargin, yPos, language);
    yPos += 6;
  }
  if (invoice.businessPhone) {
    addText(pdf, invoice.businessPhone, leftMargin, yPos, language);
    yPos += 6;
  }
  
  // Client information
  let clientYPos = 60;
  const clientX = isRTL ? 20 : pageWidth - 80;
  pdf.setFontSize(14);
  pdf.setTextColor(51, 51, 51);
  addText(pdf, labels.billTo, clientX, clientYPos, language);
  
  clientYPos += 10;
  pdf.setFontSize(12);
  if (invoice.clientName) {
    addText(pdf, invoice.clientName, clientX, clientYPos, language);
    clientYPos += 6;
  }
  if (invoice.clientAddress) {
    const addressLines = invoice.clientAddress.split('\n');
    addressLines.forEach(line => {
      addText(pdf, line, clientX, clientYPos, language);
      clientYPos += 6;
    });
  }
  if (invoice.clientEmail) {
    addText(pdf, invoice.clientEmail, clientX, clientYPos, language);
    clientYPos += 6;
  }
  
  // Items table
  yPos = Math.max(yPos, clientYPos) + 20;
  
  // Table headers
  pdf.setFontSize(12);
  pdf.setTextColor(51, 51, 51);
  pdf.setFillColor(245, 245, 245);
  pdf.rect(20, yPos - 5, pageWidth - 40, 10, 'F');
  
  // Adjust header positions for RTL
  if (isRTL) {
    addText(pdf, labels.amount, 25, yPos, language);
    addText(pdf, labels.rate, 65, yPos, language);
    addText(pdf, labels.quantity, 105, yPos, language);
    addText(pdf, labels.description, 125, yPos, language);
  } else {
    addText(pdf, labels.description, 25, yPos, language);
    addText(pdf, labels.quantity, pageWidth - 120, yPos, language);
    addText(pdf, labels.rate, pageWidth - 80, yPos, language);
    addText(pdf, labels.amount, pageWidth - 40, yPos, language);
  }
  
  yPos += 15;
  
  // Items
  (invoice.items || []).forEach(item => {
    if (yPos > pageHeight - 50) {
      pdf.addPage();
      addFontSupport(pdf, language);
      yPos = 30;
    }
    
    if (isRTL) {
      addText(pdf, formatCurrency(item.amount, currency), 25, yPos, language);
      addText(pdf, formatCurrency(item.rate, currency), 65, yPos, language);
      addText(pdf, item.quantity.toString(), 105, yPos, language);
      const descHeight = addText(pdf, item.description, 125, yPos, language, { maxWidth: 60 });
      yPos += Math.max(descHeight, 10);
    } else {
      // Description (with word wrap)
      const descHeight = addText(pdf, item.description, 25, yPos, language, { maxWidth: 100 });
      addText(pdf, item.quantity.toString(), pageWidth - 120, yPos, language);
      addText(pdf, formatCurrency(item.rate, currency), pageWidth - 80, yPos, language);
      addText(pdf, formatCurrency(item.amount, currency), pageWidth - 40, yPos, language);
      yPos += Math.max(descHeight, 10);
    }
  });
  
  // Totals
  yPos += 10;
  const totalsX = isRTL ? 25 : pageWidth - 80;
  
  const subtotalText = `${labels.subtotal}: ${formatCurrency(invoice.subtotal || 0, currency)}`;
  addText(pdf, subtotalText, totalsX, yPos, language);
  yPos += 8;
  
  if ((invoice.taxRate || 0) > 0) {
    const taxText = `${labels.tax} (${invoice.taxRate}%): ${formatCurrency(invoice.taxAmount || 0, currency)}`;
    addText(pdf, taxText, totalsX, yPos, language);
    yPos += 8;
  }
  
  // Total line
  pdf.setFontSize(14);
  pdf.setFont('helvetica', 'bold');
  const totalText = `${labels.total}: ${formatCurrency(invoice.total || 0, currency)}`;
  addText(pdf, totalText, totalsX, yPos, language);
  
  // Payment terms and notes
  yPos += 20;
  pdf.setFontSize(12);
  pdf.setFont('helvetica', 'normal');
  
  if (invoice.paymentTerms) {
    const paymentText = `${labels.paymentTerms}: ${invoice.paymentTerms}`;
    addText(pdf, paymentText, leftMargin, yPos, language);
    yPos += 10;
  }
  
  if (invoice.notes) {
    addText(pdf, labels.notes, leftMargin, yPos, language);
    yPos += 8;
    const notesHeight = addText(pdf, invoice.notes, leftMargin, yPos, language, { maxWidth: pageWidth - 40 });
    yPos += notesHeight;
  }
  
  // Thank you message
  yPos += 10;
  pdf.setTextColor(102, 102, 102);
  addText(pdf, labels.thankYou, leftMargin, yPos, language);
  
  // Save the PDF
  const fileName = `invoice-${invoice.invoiceNumber || Date.now()}.pdf`;
  pdf.save(fileName);
};

export const generateInvoiceSummaryPDF = async (invoices: Invoice[]): Promise<void> => {
  const pdf = new jsPDF('p', 'mm', 'a4');
  const pageWidth = pdf.internal.pageSize.getWidth();
  
  // Use the first invoice's language for the summary, or default to English
  const language = invoices.length > 0 ? invoices[0].language : 'en';
  const labels = getLabels({ language });
  
  addFontSupport(pdf, language);
  
  // Title
  pdf.setFontSize(20);
  pdf.setTextColor(51, 51, 51);
  addText(pdf, 'Invoice Summary Report', 20, 30, language);
  
  // Date range
  pdf.setFontSize(12);
  pdf.setTextColor(102, 102, 102);
  addText(pdf, `Generated on: ${new Date().toLocaleDateString()}`, 20, 40, language);
  addText(pdf, `Total Invoices: ${invoices.length}`, 20, 50, language);
  
  // Calculate totals
  const totalAmount = invoices.reduce((sum, inv) => sum + (inv.total || 0), 0);
  addText(pdf, `Total Amount: $${totalAmount.toFixed(2)}`, 20, 60, language);
  
  // Table headers
  let yPos = 80;
  pdf.setFillColor(245, 245, 245);
  pdf.rect(20, yPos - 5, pageWidth - 40, 10, 'F');
  
  pdf.setTextColor(51, 51, 51);
  addText(pdf, 'Invoice #', 25, yPos, language);
  addText(pdf, 'Client', 70, yPos, language);
  addText(pdf, 'Date', 120, yPos, language);
  addText(pdf, 'Amount', pageWidth - 40, yPos, language);
  
  yPos += 15;
  
  // Invoice list
  invoices.forEach(invoice => {
    if (yPos > 270) {
      pdf.addPage();
      addFontSupport(pdf, language);
      yPos = 30;
    }
    
    pdf.setFontSize(10);
    addText(pdf, invoice.invoiceNumber || '', 25, yPos, language);
    addText(pdf, invoice.clientName || '', 70, yPos, language);
    addText(pdf, invoice.date ? new Date(invoice.date).toLocaleDateString() : '', 120, yPos, language);
    addText(pdf, `$${(invoice.total || 0).toFixed(2)}`, pageWidth - 40, yPos, language);
    
    yPos += 8;
  });
  
  pdf.save('invoice-summary.pdf');
};

export const generateAllInvoicesPDF = async (invoices: Invoice[]): Promise<void> => {
  const pdf = new jsPDF('p', 'mm', 'a4');
  
  for (let i = 0; i < invoices.length; i++) {
    if (i > 0) {
      pdf.addPage();
    }
    
    const invoice = invoices[i];
    const labels = getLabels(invoice);
    const currency = invoice.currency || 'USD';
    const language = invoice.language || 'en';
    const pageWidth = pdf.internal.pageSize.getWidth();
    
    addFontSupport(pdf, language);
    
    const isRTL = language === 'ar' || language === 'ur';
    const leftMargin = isRTL ? pageWidth - 170 : 20;
    
    // Header
    pdf.setFontSize(24);
    pdf.setTextColor(51, 51, 51);
    addText(pdf, labels.invoice, leftMargin, 30, language);
    
    // Invoice number
    pdf.setFontSize(12);
    pdf.setTextColor(102, 102, 102);
    addText(pdf, `#${invoice.invoiceNumber || ''}`, leftMargin, 40, language);
    
    // Date information
    const dateText = `${labels.date}: ${invoice.date ? new Date(invoice.date).toLocaleDateString() : ''}`;
    const dueText = `${labels.due}: ${invoice.dueDate ? new Date(invoice.dueDate).toLocaleDateString() : ''}`;
    
    if (isRTL) {
      addText(pdf, dateText, 20, 30, language);
      addText(pdf, dueText, 20, 40, language);
    } else {
      addText(pdf, dateText, pageWidth - 60, 30, language);
      addText(pdf, dueText, pageWidth - 60, 40, language);
    }
    
    // Business and client info (simplified for bulk export)
    let yPos = 60;
    pdf.setFontSize(12);
    const fromText = `${labels.from}: ${invoice.businessName || ''}`;
    const billToText = `${labels.billTo}: ${invoice.clientName || ''}`;
    addText(pdf, fromText, leftMargin, yPos, language);
    addText(pdf, billToText, leftMargin, yPos + 10, language);
    
    yPos += 30;
    
    // Items summary
    addText(pdf, 'Items:', leftMargin, yPos, language);
    yPos += 10;
    
    (invoice.items || []).forEach(item => {
      pdf.setFontSize(10);
      const itemText = `${item.description} - ${item.quantity} x ${formatCurrency(item.rate, currency)} = ${formatCurrency(item.amount, currency)}`;
      addText(pdf, itemText, leftMargin + 5, yPos, language);
      yPos += 6;
    });
    
    // Total
    yPos += 10;
    pdf.setFontSize(14);
    pdf.setFont('helvetica', 'bold');
    const totalText = `${labels.total}: ${formatCurrency(invoice.total || 0, currency)}`;
    addText(pdf, totalText, leftMargin, yPos, language);
    pdf.setFont('helvetica', 'normal');
  }
  
  pdf.save('all-invoices.pdf');
};