import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Download, Edit, Share2 } from 'lucide-react';
import Navbar from '@/components/Navbar';
import InvoiceTemplate from '@/components/InvoiceTemplate';
import { Invoice, getInvoices } from '@/lib/invoice';

export default function InvoicePreview() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [invoice, setInvoice] = useState<Invoice | null>(null);

  useEffect(() => {
    if (id === 'preview') {
      // Load from session storage for preview
      const previewData = sessionStorage.getItem('previewInvoice');
      if (previewData) {
        setInvoice(JSON.parse(previewData));
      }
    } else {
      // Load from localStorage
      const invoices = getInvoices();
      const found = invoices.find(inv => inv.id === id);
      if (found) {
        setInvoice(found);
      } else {
        navigate('/dashboard');
      }
    }
  }, [id, navigate]);

  const handleDownloadPDF = () => {
    // Simple PDF generation using browser print
    window.print();
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Invoice ${invoice?.invoiceNumber}`,
          text: `Invoice from ${invoice?.businessName}`,
          url: window.location.href,
        });
      } catch (err) {
        console.log('Error sharing:', err);
      }
    } else {
      // Fallback: copy URL to clipboard
      navigator.clipboard.writeText(window.location.href);
      alert('Invoice URL copied to clipboard!');
    }
  };

  if (!invoice) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
          <p className="text-gray-600">Invoice not found.</p>
          <Link to="/dashboard">
            <Button className="mt-4">Back to Dashboard</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header Actions */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 space-y-4 sm:space-y-0">
          <div className="flex items-center space-x-4">
            <Button 
              variant="outline" 
              onClick={() => navigate(-1)}
              className="flex items-center space-x-2"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Back</span>
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Invoice Preview</h1>
              <p className="text-gray-600">#{invoice.invoiceNumber}</p>
            </div>
          </div>
          
          <div className="flex flex-wrap gap-2">
            {id !== 'preview' && (
              <Link to={`/edit/${id}`}>
                <Button variant="outline" className="flex items-center space-x-2">
                  <Edit className="h-4 w-4" />
                  <span>Edit</span>
                </Button>
              </Link>
            )}
            
            <Button 
              variant="outline" 
              onClick={handleShare}
              className="flex items-center space-x-2"
            >
              <Share2 className="h-4 w-4" />
              <span>Share</span>
            </Button>
            
            <Button 
              onClick={handleDownloadPDF}
              className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700"
            >
              <Download className="h-4 w-4" />
              <span>Download PDF</span>
            </Button>
          </div>
        </div>

        {/* Invoice Template */}
        <div className="print:shadow-none">
          <InvoiceTemplate invoice={invoice} />
        </div>

        {/* Print Styles */}
        <style jsx global>{`
          @media print {
            body * {
              visibility: hidden;
            }
            .print\\:shadow-none, .print\\:shadow-none * {
              visibility: visible;
            }
            .print\\:shadow-none {
              position: absolute;
              left: 0;
              top: 0;
              width: 100%;
            }
            nav, .no-print {
              display: none !important;
            }
          }
        `}</style>
      </div>
    </div>
  );
}