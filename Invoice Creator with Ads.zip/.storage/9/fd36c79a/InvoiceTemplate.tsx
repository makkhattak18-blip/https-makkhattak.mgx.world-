import { Invoice } from '@/lib/invoice';
import { Card, CardContent } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';

interface InvoiceTemplateProps {
  invoice: Partial<Invoice>;
}

export default function InvoiceTemplate({ invoice }: InvoiceTemplateProps) {
  return (
    <Card className="max-w-4xl mx-auto">
      <CardContent className="p-8">
        {/* Header */}
        <div className="flex justify-between items-start mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">INVOICE</h1>
            <p className="text-gray-600">#{invoice.invoiceNumber}</p>
          </div>
          <div className="text-right">
            <div className="text-sm text-gray-600">
              <p>Date: {invoice.date ? new Date(invoice.date).toLocaleDateString() : ''}</p>
              <p>Due: {invoice.dueDate ? new Date(invoice.dueDate).toLocaleDateString() : ''}</p>
            </div>
          </div>
        </div>

        {/* Business and Client Info */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-3">From:</h3>
            <div className="text-gray-700">
              <p className="font-medium">{invoice.businessName}</p>
              {invoice.businessAddress && (
                <div className="whitespace-pre-line text-sm mt-1">
                  {invoice.businessAddress}
                </div>
              )}
              {invoice.businessEmail && (
                <p className="text-sm mt-1">{invoice.businessEmail}</p>
              )}
              {invoice.businessPhone && (
                <p className="text-sm">{invoice.businessPhone}</p>
              )}
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-3">Bill To:</h3>
            <div className="text-gray-700">
              <p className="font-medium">{invoice.clientName}</p>
              {invoice.clientAddress && (
                <div className="whitespace-pre-line text-sm mt-1">
                  {invoice.clientAddress}
                </div>
              )}
              {invoice.clientEmail && (
                <p className="text-sm mt-1">{invoice.clientEmail}</p>
              )}
            </div>
          </div>
        </div>

        {/* Items Table */}
        <div className="mb-8">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b-2 border-gray-200">
                  <th className="text-left py-3 px-2 font-semibold text-gray-900">Description</th>
                  <th className="text-center py-3 px-2 font-semibold text-gray-900 w-20">Qty</th>
                  <th className="text-right py-3 px-2 font-semibold text-gray-900 w-24">Rate</th>
                  <th className="text-right py-3 px-2 font-semibold text-gray-900 w-24">Amount</th>
                </tr>
              </thead>
              <tbody>
                {(invoice.items || []).map((item) => (
                  <tr key={item.id} className="border-b border-gray-100">
                    <td className="py-3 px-2 text-gray-700">{item.description}</td>
                    <td className="py-3 px-2 text-center text-gray-700">{item.quantity}</td>
                    <td className="py-3 px-2 text-right text-gray-700">${item.rate.toFixed(2)}</td>
                    <td className="py-3 px-2 text-right text-gray-700">${item.amount.toFixed(2)}</td>
                  </tr>
                ))}
                {(invoice.items || []).length === 0 && (
                  <tr>
                    <td colSpan={4} className="py-8 text-center text-gray-500">
                      No items added yet
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Totals */}
        <div className="flex justify-end mb-8">
          <div className="w-full max-w-xs">
            <div className="space-y-2">
              <div className="flex justify-between py-2">
                <span className="text-gray-700">Subtotal:</span>
                <span className="text-gray-900">${(invoice.subtotal || 0).toFixed(2)}</span>
              </div>
              
              {(invoice.taxRate || 0) > 0 && (
                <div className="flex justify-between py-2">
                  <span className="text-gray-700">Tax ({invoice.taxRate}%):</span>
                  <span className="text-gray-900">${(invoice.taxAmount || 0).toFixed(2)}</span>
                </div>
              )}
              
              <Separator />
              
              <div className="flex justify-between py-2 text-lg font-semibold">
                <span className="text-gray-900">Total:</span>
                <span className="text-gray-900">${(invoice.total || 0).toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Payment Terms and Notes */}
        <div className="space-y-4">
          {invoice.paymentTerms && (
            <div>
              <h4 className="font-semibold text-gray-900 mb-2">Payment Terms:</h4>
              <p className="text-gray-700 text-sm">{invoice.paymentTerms}</p>
            </div>
          )}
          
          {invoice.notes && (
            <div>
              <h4 className="font-semibold text-gray-900 mb-2">Notes:</h4>
              <p className="text-gray-700 text-sm whitespace-pre-line">{invoice.notes}</p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="mt-12 pt-4 border-t border-gray-200 text-center text-sm text-gray-500">
          <p>Thank you for your business!</p>
        </div>
      </CardContent>
    </Card>
  );
}