# Invoice Creator Website - MVP Todo

## Core Features to Implement:
1. **Landing Page** - Professional homepage with clear value proposition for Google Ads traffic
2. **Invoice Creator** - Form-based invoice generation with all standard fields
3. **Invoice Preview** - Real-time preview and PDF generation capability
4. **Invoice Management** - List and manage created invoices (localStorage)
5. **Google Ads Optimization** - Landing page optimized for conversions

## Files to Create/Modify:
1. `src/pages/Index.tsx` - Landing page with hero section, features, CTA
2. `src/pages/CreateInvoice.tsx` - Invoice creation form
3. `src/pages/InvoicePreview.tsx` - Invoice preview and PDF export
4. `src/pages/Dashboard.tsx` - Invoice management dashboard
5. `src/components/InvoiceForm.tsx` - Reusable invoice form component
6. `src/components/InvoiceTemplate.tsx` - Invoice display template
7. `src/components/Navbar.tsx` - Navigation component
8. `src/lib/invoice.ts` - Invoice data types and utilities
9. `index.html` - Update title and meta tags for SEO/Google Ads

## Implementation Priority:
- Focus on conversion-optimized landing page
- Simple but professional invoice creation
- Clean, trustworthy design
- Mobile responsive
- Fast loading for better ad performance